package com.cts.mfrp.parksmart.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.mfrp.parksmart.model.Bookings;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Integer> {

	boolean existsByParkingSlotSlotIdAndArrivalLessThanAndLeavingGreaterThan(
	        Integer slotId,
	        LocalDateTime arrival,
	        LocalDateTime leaving
	);

    @Query("""
            SELECT ps.name
            FROM Bookings b
            JOIN b.parkingSlot s
            JOIN s.parkingSpace ps
            WHERE b.user.email = :email
            AND (
                LOWER(ps.name) LIKE LOWER(CONCAT('%', :query, '%')) OR
                LOWER(ps.location) LIKE LOWER(CONCAT('%', :query, '%')) OR
                LOWER(ps.city) LIKE LOWER(CONCAT('%', :query, '%'))
            )
            """)
    List<String> findSuggestionsByUserAndQuery(@Param("email") String email, @Param("query") String query);

    @Query("SELECT b FROM Bookings b WHERE b.user.userId = :userId ORDER BY b.arrival DESC")
    List<Bookings> findByUserId(@Param("userId") int userId);

    @Query("""
            SELECT b FROM Bookings b
            JOIN b.parkingSlot s
            WHERE s.parkingSpace.spaceId = :spaceId
            ORDER BY b.arrival DESC
            """)
    List<Bookings> findBySpaceId(@Param("spaceId") Integer spaceId);

    @Query("""
            SELECT COUNT(b) > 0 FROM Bookings b
            JOIN b.parkingSlot s
            WHERE s.parkingSpace.spaceId = :spaceId
            AND b.status IN ('CONFIRMED','UPCOMING','ACTIVE')
            """)
    boolean existsActiveOrUpcomingBySpaceId(@Param("spaceId") Integer spaceId);

    @Query("""
            SELECT COUNT(b) > 0 FROM Bookings b
            WHERE b.parkingSlot.slotId = :slotId
            AND b.status IN ('CONFIRMED','UPCOMING','ACTIVE')
            """)
    boolean existsActiveOrUpcomingBySlotId(@Param("slotId") Integer slotId);
}
