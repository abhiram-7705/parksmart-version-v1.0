package com.cts.mfrp.parksmart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.mfrp.parksmart.model.ContactRequests;

@Repository
public interface ContactRequestsRepository extends JpaRepository<ContactRequests, Integer> {

	
	
}
