package com.cts.mfrp.parksmart.service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.mfrp.parksmart.dto.LocationSuggestionDTO;
import com.cts.mfrp.parksmart.dto.ParkingCardDTO;
import com.cts.mfrp.parksmart.dto.SpaceSearchRequestDTO;
import com.cts.mfrp.parksmart.model.ParkingSlots;
import com.cts.mfrp.parksmart.model.ParkingSpaces;
import com.cts.mfrp.parksmart.model.Reviews;
import com.cts.mfrp.parksmart.repository.BookingsRepository;
import com.cts.mfrp.parksmart.repository.ParkingSlotsRepository;
import com.cts.mfrp.parksmart.repository.ParkingSpacesRepository;

@Service
public class SearchService {

	@Autowired
	private ParkingSpacesRepository parkingSpaceRepository;
	@Autowired
	private ParkingSlotsRepository parkingSlotsRepository;
	@Autowired
	private BookingsRepository bookingsRepository;

	public List<LocationSuggestionDTO> getLocationSuggestions(String query) {

	    if (query == null || query.length() < 2) {
	        return Collections.emptyList();
	    }

	    return parkingSpaceRepository
	            .findLocationSuggestionsWithCoords(query)
	            .stream()
	            .distinct()
	            .limit(10)
	            .toList();
	}
	
	private ParkingCardDTO mapToDTO(ParkingSpaces space, double userLat, double userLng) {
		
		ParkingCardDTO dto = new ParkingCardDTO();
		dto.setSpaceId(space.getSpaceId());
		dto.setName(space.getName());
		dto.setType(space.getType());
		dto.setLocation(space.getLocation());
		dto.setCity(space.getCity());
		dto.setPricePerHour(space.getPricePerHour());
		dto.setLatitude(space.getLatitude());
		dto.setLongitude(space.getLongitude());
		dto.setDistance(calculateDistance(userLat, userLng, space.getLatitude(), space.getLongitude()));
		
		List<String> facilities = new java.util.ArrayList<>();
		
		if (space.isCctv()) 
			facilities.add("cctv");
		if (space.isEvCharging()) 
			facilities.add("ev");
		if (space.isGuarded()) 
			facilities.add("guarded");
		if (space.isCoveredFence()) 
			facilities.add("covered");
		
		dto.setFacilities(facilities);
		
		List<Reviews> reviews = space.getReviews();
		double avgRating = 0.0;
		int totalRatings = 0;

		if (reviews != null && !reviews.isEmpty()) {

		    totalRatings = reviews.size();

		    double sum = 0.0;
		    for (Reviews r : reviews) {
		        sum += r.getRating();
		    }

		    avgRating = sum / totalRatings;
		}

		dto.setRating(avgRating);
		dto.setCountRating(totalRatings);
		
		
		return dto;
	}

	public List<ParkingCardDTO> searchSpaces(SpaceSearchRequestDTO request) {
	
	    double userLat = request.getLatitude();
	    double userLng = request.getLongitude();
	
	    LocalDateTime[] time = resolveTime(request);
	    LocalDateTime arrival = time[0];
	    LocalDateTime leaving = time[1];
	
	    double radius = request.getRadius() != null ? request.getRadius() : 5.0;
	
	    List<ParkingSpaces> spaces =
	            parkingSpaceRepository.findByIsActiveTrue();
	    
	    System.out.println(spaces);
	    
	    List<ParkingCardDTO> result = spaces.stream()
	            .map(space -> mapToDTO(space, userLat, userLng))
	            .collect(Collectors.toList());

	    result = result.stream()
	            .filter(dto -> dto.getDistance() <= radius)
	            .collect(Collectors.toList());

	    result = result.stream()
	            .filter(dto -> isSpaceAvailable(dto.getSpaceId(), arrival, leaving))
	            .collect(Collectors.toList());

	    result = result.stream()
	            .filter(dto -> filterByType(dto, request.getTypes()))
	            .collect(Collectors.toList());

	    result = result.stream()
	            .filter(dto -> filterByPrice(dto, request.getMinPrice(), request.getMaxPrice()))
	            .collect(Collectors.toList());

	    result = result.stream()
	            .filter(dto -> filterByFacilities(dto, request.getAmenities()))
	            .collect(Collectors.toList());

	    sortResults(result, request.getSortBy());
	
	    return paginate(result, request.getPage(), request.getLimit());
	}


	private List<ParkingCardDTO> paginate(
	        List<ParkingCardDTO> list, int page, int limit) {
	
	    int fromIndex = Math.max(0, (page - 1) * limit);
	    int toIndex = Math.min(list.size(), fromIndex + limit);
	
	    if (fromIndex >= list.size()) {
	        return List.of();
	    }
	
	    return list.subList(fromIndex, toIndex);
	}

	private LocalDateTime[] resolveTime(SpaceSearchRequestDTO request) {

	    LocalDateTime now = LocalDateTime.now().plusMinutes(15);

	    LocalDateTime arrival;
	    LocalDateTime leaving;

	    if (request.getArrival() == null) {
	        arrival = now;
	        leaving = arrival.plusHours(1);
	    } else {
	        arrival = LocalDateTime.parse(request.getArrival());
	        leaving = LocalDateTime.parse(request.getLeaving());

	        if (!leaving.isAfter(arrival)) {
	            throw new IllegalArgumentException("Leaving time must be after arrival time");
	        }
	        if (arrival.isBefore(now)) {
	            throw new IllegalArgumentException("Arrival must be at least 15 minutes from now");
	        }
	    }

	    return new LocalDateTime[]{arrival, leaving};
	}
	

	private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {

		final int R = 6371;
		double dLat = Math.toRadians(lat2 - lat1);
		double dLon = Math.toRadians(lon2 - lon1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

		return R * c;
	}
	
	private boolean isSpaceAvailable(Integer spaceId, LocalDateTime arrival, LocalDateTime leaving) {

		List<ParkingSlots> slots = parkingSlotsRepository.findBySpaceId(spaceId);

		for (ParkingSlots slot : slots) {

	        boolean booked = bookingsRepository.existsByParkingSlotSlotIdAndArrivalLessThanAndLeavingGreaterThan(
	                        slot.getSlotId(),
	                        leaving,
	                        arrival
	                );
	        if (!booked) {
	            return true;
	        }
		}
		return false;
	}
	
	private boolean filterByType(ParkingCardDTO dto, List<String> types) {
	    if (types == null || types.isEmpty()) {
	        return true;
	   
	     }
	    return types.stream()
	            .map(String::toLowerCase)
	            .anyMatch(t -> t.equals(dto.getType().toLowerCase()));
	}
	
	private boolean filterByPrice(ParkingCardDTO dto, Double minPrice, Double maxPrice) {

		double price = dto.getPricePerHour();

		if (minPrice != null && price < minPrice) {
			return false;
		}

		if (maxPrice != null && price > maxPrice) {
			return false;
		}

		return true;
	}
		private boolean filterByFacilities(ParkingCardDTO dto, List<String> facilities) {

	    if (facilities == null || facilities.isEmpty()) {
	        return true;
	    }

	    List<String> dtoFacilitiesLower = dto.getFacilities().stream()
	            .map(String::toLowerCase)
	            .toList();

	    return facilities.stream()
	            .map(String::toLowerCase)
	            .allMatch(dtoFacilitiesLower::contains);
	}
	
	private void sortResults(List<ParkingCardDTO> list, String sortBy) {

	    if (sortBy == null) {
	        return;
	    }

	    switch (sortBy.toLowerCase()) {

	        case "distance":
	            list.sort(Comparator.comparing(ParkingCardDTO::getDistance));
	            break;

	        case "price_low":
	            list.sort(Comparator.comparing(ParkingCardDTO::getPricePerHour));
	            break;

	        case "price_high":
	            list.sort(Comparator.comparing(ParkingCardDTO::getPricePerHour).reversed());
	            break;

	        case "rating":
	            list.sort(Comparator.comparing(ParkingCardDTO::getRating).reversed());
	            break;
	    }
	}
	
}
