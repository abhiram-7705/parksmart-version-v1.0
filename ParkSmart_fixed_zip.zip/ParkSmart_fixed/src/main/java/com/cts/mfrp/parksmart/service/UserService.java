package com.cts.mfrp.parksmart.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.mfrp.parksmart.dto.LoginRequestDTO;
import com.cts.mfrp.parksmart.dto.SignUpRequestDTO;
import com.cts.mfrp.parksmart.dto.UserProfileDTO;
import com.cts.mfrp.parksmart.dto.WalletDTO;
import com.cts.mfrp.parksmart.model.Users;
import com.cts.mfrp.parksmart.model.WalletTransactions;
import com.cts.mfrp.parksmart.repository.UserRepository;
import com.cts.mfrp.parksmart.repository.WalletTransactionsRepository;

@Service
public class UserService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WalletTransactionsRepository walletTransactionsRepository;

    @Autowired
    private EmailService emailService;

    public String registerUser(SignUpRequestDTO request) {
        String email = request.getEmail().trim().toLowerCase();
        if (userRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("email already exists");
        }

        String password = request.getPassword().trim();
        if (!password.equals(request.getConfirmPassword())) {
            throw new RuntimeException("password and confirm password does not match");
        }

        Users user = new Users();
        user.setUserName(request.getUserName());
        user.setEmail(email);
        user.setPhoneNumber(request.getPhoneNumber().trim());
        user.setPassword(passwordEncoder.encode(password));
        user.setBalance(10000.0);
        user.setRole("USER");

        userRepository.save(user);

        // Credit welcome bonus transaction
        WalletTransactions txn = new WalletTransactions();
        txn.setUser(user);
        txn.setAmount(10000.0);
        txn.setTransactionType("CREDIT");
        txn.setDescription("Welcome bonus on signup");
        txn.setTimestamp(LocalDateTime.now());
        walletTransactionsRepository.save(txn);

        return "Account created successfully";
    }

    public Users login(LoginRequestDTO request) {
        String email = request.getEmail().trim().toLowerCase();
        String password = request.getPassword().trim();

        Users user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Invalid email or password");
        }

        return user;
    }

    public UserProfileDTO getUserProfile(String email) {
        Users user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        UserProfileDTO dto = new UserProfileDTO();
        dto.setUserId(user.getUserId());
        dto.setUserName(user.getUserName());
        dto.setEmail(user.getEmail());
        dto.setBalance(user.getBalance());
        dto.setPhoneNumber(user.getPhoneNumber());
        dto.setRole(user.getRole() != null ? user.getRole() : "USER");
        return dto;
    }

    public List<WalletDTO> getWalletDetails(String email) {
        Users user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<WalletTransactions> txns = walletTransactionsRepository.findByUserOrderByTimestampDesc(user);

        return txns.stream().map(t -> {
            WalletDTO dto = new WalletDTO();
            dto.setTransactionId(t.getTransactionId());
            dto.setAmount(t.getAmount());
            dto.setTransactionType(t.getTransactionType());
            dto.setDescription(t.getDescription());
            dto.setTransactionTime(t.getTimestamp());
            return dto;
        }).collect(Collectors.toList());
    }

    public void generateResetToken(String email) {
        Users user = userRepository.findByEmail(email.trim().toLowerCase())
                .orElseThrow(() -> new RuntimeException("No account with that email"));
        String token = UUID.randomUUID().toString();
        user.setResetToken(token);
        user.setResetTokenExpiry(LocalDateTime.now().plusHours(1));
        userRepository.save(user);
        emailService.sendPasswordResetEmail(user.getEmail(), token);
    }

    public void validateResetToken(String token) {
        Users user = userRepository.findByResetToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid or expired token"));
        if (user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token expired");
        }
    }

    public void resetPassword(String token, String password) {
        Users user = userRepository.findByResetToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid token"));
        if (user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token expired");
        }
        user.setPassword(passwordEncoder.encode(password));
        user.setResetToken(null);
        user.setResetTokenExpiry(null);
        userRepository.save(user);
    }    
    
}
